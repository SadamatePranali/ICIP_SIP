import java.util.ArrayList;
import java.util.List;

public class SeatingArrangement {
    private List<Room> rooms;

    public SeatingArrangement() {
        this.rooms = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public void assignStudentToRoom(Student student, Room room) {
        if (rooms.contains(room)) {
            // Check if room has capacity
            if (room.getStudents().size() < room.getCapacity()) {
                room.addStudent(student);
                System.out.println("Assigned " + student.getName() + " to Room " + room.getRoomNumber());
            } else {
                System.out.println("Room " + room.getRoomNumber() + " is full.");
            }
        } else {
            System.out.println("Room not found.");
        }
    }

    public List<Room> getRooms() {
        return rooms;
    }

    public void setRooms(List<Room> rooms) {
        this.rooms = rooms;
    }

    public void displayRooms() {
        for (Room room : rooms) {
            System.out.println(room);
        }
    }

    public static void main(String[] args) {
        SeatingArrangement seatingArrangement = new SeatingArrangement();

        Room room1 = new Room(101, 30);
        Room room2 = new Room(102, 25);

        seatingArrangement.addRoom(room1);
        seatingArrangement.addRoom(room2);

        Student student1 = new Student("Pranali", 1);
        Student student2 = new Student("Sharvari ", 1);

        seatingArrangement.assignStudentToRoom(student1, room1);
        seatingArrangement.assignStudentToRoom(student2, room1); // This will print that Room 101 is full

        seatingArrangement.assignStudentToRoom(student2, room2); // This will assign Bob to Room 102

        seatingArrangement.displayRooms();
    }
}
